/*
*File: EncodeInput.h
*Project : EncodeInput
*Programmer : Ning Li & Will Wei
*Date : Feb 16, 2021
*Description : This file contains all liberaries, constants and prototypes.
*/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#pragma warning(disable : 4996)

//constants
#define NUM_CHAR 51
#define DATA_SIZE 16
#define ADDRESS_SIZE 2
#define BYTE_SIZE 1


//prototypes
void fileOperation(char inputFilename[], char outputFilename[], bool srecSwitch);
void srecMode(FILE* inputFile, FILE* outputFile);
void asemMode(FILE* inputFile, FILE* outputFile);
int checkSUM(int count, int address, int checkSum);