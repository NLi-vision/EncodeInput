/*
*File: EncodeInput.c
*Project : EncodeInput
*Programmer : Ning Li
*Date : Feb 16, 2021
*Description : This program is a linux utility for encoding from binary to SREC or assembly format.
*/


#include "../inc/encodeInput.h"

int main(int argc, char* argv[]) 
{
	char parameter[NUM_CHAR] = "";
	char inputFilename[NUM_CHAR] = "";
	char outputFilename[NUM_CHAR] = "";

	bool srecSwitch = false;
	
	if (argc == 1) 
	{		
		fileOperation(inputFilename, outputFilename, srecSwitch);		
	}
	else if (argc >= 2 && argc <= 5)
	{
		for (int i = 1; i < argc; i++)
		{
			// copy the command line parameter 
			strcpy(parameter, argv[i]);

			// if "-h" switch is specified
			if (strcmp(parameter, "-h") == 0) 
			{				
				printf("Command format:\nencodeInput <[-i]INPUTFILENAME> <[-o]OUTPUTFILENAME> <-srec> <-h>\n");
			}

			//if "-srec" switch is specified
			else if (strcmp(parameter, "-srec") == 0) 
			{
				srecSwitch = true;
			}

			//if the input filename is specified
			else if (parameter[0] == '-' && parameter[1] == 'i')
			{				
				// if the input filename is specified													
				if (parameter[2] != '\0')
				{
					char* pCopy = &parameter[2];
					strcpy(inputFilename, pCopy);
				}
			}
			else if (parameter[0] == '-' && parameter[1] == 'o')
			{
				//if the output filename is specified 
				if (parameter[2] != '\0')
				{
					char* pCopy = &parameter[2];
					strcpy(outputFilename, pCopy);
				}
			}
			else
			{
				printf("Invalid switch.\n");
				printf("Command format:\nencodeInput <[-i]INPUTFILENAME> <[-o]OUTPUTFILENAME> <-srec> <-h>\n");
				return 0;
			}
		}

		fileOperation(inputFilename, outputFilename, srecSwitch);
	}
	else
	{
		printf("Invalid switch.\n");
		printf("Command format:\nencodeInput <[-i]INPUTFILENAME> <[-o]OUTPUTFILENAME> <-srec> <-h>\n");
	}	

	return 0;
}
