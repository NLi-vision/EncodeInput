/*
*File: EncodeOperation.c
*Project : EncodeInput
*Programmer : Ning Li
*Date : Feb 16, 2021
*Description : This file includes the functions used for encoding.
*/


#include "../inc/encodeInput.h"

/*
*Function: srecMode
*Parameter: FILE* inputFile
*           FILE* outputFile
*Return: nothing
*Description: This function takes the input file stream, after encoding in srec mode and write back 
*             to the output file stream
*/

void srecMode(FILE* inputFile, FILE* outputFile)
{
	char name[17] = "NING";

	//4 format types of records
	char format[4][3] = {"S0", "S1", "S5", "S9"};
	unsigned char buffer[DATA_SIZE + BYTE_SIZE] = "";
	int getBytes = 0;
	int s1Count = 0;
	int addressS1 = 0;
	
	//write s0 line
	int CCS0 = ADDRESS_SIZE + strlen(name) + BYTE_SIZE;
	int AAAAS0 = 0;
	//TT CC AAAA
	fprintf(outputFile, "%s%02X%04X", format[0], CCS0, AAAAS0);
	int sumS0Data = 0;
	for (int i = 0; i < strlen(name); i++)
	{
		//write s0 DD..DD
		fprintf(outputFile, "%02X", name[i]);
		sumS0Data += name[i];
	}

	//Call function checkSUM to get MM value
	int MM = checkSUM(CCS0, AAAAS0, sumS0Data);
	//write s0 MM 
	fprintf(outputFile, "%02X\n", MM);	

	//write s1 line 
	while ((getBytes = fread(buffer, BYTE_SIZE, DATA_SIZE, inputFile))!=0)
	{		
		//write S1 lines
		int CCS1 = ADDRESS_SIZE + getBytes + BYTE_SIZE;
		int sumS1Data = 0;

		//TT CC AAAA
		fprintf(outputFile, "%s%02X%04X", format[1], CCS1, addressS1);

		for (int i = 0; i < getBytes; i++)
		{
			//DD..DD
			fprintf(outputFile, "%02X", buffer[i]);

			sumS1Data += buffer[i];
		}

		//Call function checkSUM to get MM value
		int MMS1 = checkSUM(CCS1, addressS1, sumS1Data);
		fprintf(outputFile, "%02X\n", MMS1);

		addressS1 += DATA_SIZE;
		s1Count++;
	}

	
	//write s5 line
	int CCS5 = ADDRESS_SIZE + BYTE_SIZE;
	int AAAAS5 = s1Count;
	int MMS5 = checkSUM(CCS5, AAAAS5, 0);
	fprintf(outputFile, "%s%02X%04X%02X\n", format[2], CCS5, AAAAS5, MMS5);
	

	//write s9 line
	int CCS9 = ADDRESS_SIZE + BYTE_SIZE;
	int AAAAS9 = 0;
	int MMS9 = checkSUM(CCS9, AAAAS9, 0);
	fprintf(outputFile, "%s%02X%04X%02X\n", format[3], CCS9, AAAAS9, MMS9);
}


/*
*Function: asemMode
*Parameter: FILE* inputFile
*           FILE* outputFile
*Return: nothing
*Description: This function takes the input file stream, after encoding in asem modeand write back
*             to the output file stream
*/

void asemMode(FILE* inputFile, FILE* outputFile)
{
	unsigned char buffer[DATA_SIZE + BYTE_SIZE] = "";

	//check if end of file and read bytes
	int getBytes = 0;
	while ((getBytes = fread(buffer, BYTE_SIZE, DATA_SIZE, inputFile))!=0)
	{
		char header[5] = "dc.b";
		fprintf(outputFile, "%s\t", header);

		for (int i = 0; i < getBytes; i++)
		{
			if (i == getBytes - 1)
			{
				fprintf(outputFile, "$%02X\n", buffer[i]);
			}
			else 
			{
				fprintf(outputFile, "$%02X,", buffer[i]);
			}
		}
	}
}


/*
*Function: checkSUM
*Parameter: int count, int address, int checkSum
*Return: mmValue
*Description: This funcion calculates the CheckSUM field for the SREC format encoding
*/

int checkSUM(int count, int address, int checkSum)
{
	int mmValue = count + address + checkSum;

	//get 1 's complement and strip off the least significant byte
	mmValue = (~mmValue) & 0xFF;
	return mmValue;
}
