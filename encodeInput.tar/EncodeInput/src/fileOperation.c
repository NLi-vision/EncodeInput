/*
*File: FileOperationt.c
*Project : EncodeInput
*Programmer : Ning Li
*Date : Feb 16, 2021
*Description : This file include the file operation functions.
*/

#include "../inc/encodeInput.h"

/*
*Function: fileOperation
*Parameter: char inputFilename[] 
*           char outputFilename[] 
*		    bool srecSwitch
*Return Value: nothing
*Description: This function open and close both the input and output files, also get and pass the content of files.
*/

void fileOperation(char inputFilename[], char outputFilename[], bool srecSwitch)
{
	FILE* inputFilep = NULL;
	FILE* outputFilep = NULL;

	// if input and output filenames are not specified
	if (strlen(inputFilename) == 0 && strlen(outputFilename) == 0)
	{
		printf("stdin input:");
		inputFilep = stdin;
		outputFilep = stdout;

		if (srecSwitch == true) 
		{
			srecMode(inputFilep, outputFilep);
		}

		else 
		{
			asemMode(inputFilep, outputFilep);
		}
	}


	//if just output filename is specified
	if (strlen(inputFilename) == 0 && strlen(outputFilename) != 0)
	{
		inputFilep = stdin;
		outputFilep = fopen(outputFilename, "wb");

		if (outputFilep == NULL) 
		{
			printf("Failed to open the output file!\n");
			return;
		}

		if (srecSwitch == true) 
		{
			srecMode(inputFilep, outputFilep);
		}
		else 
		{
			asemMode(inputFilep, outputFilep);
		}
	}


	//if just input filename is specified 
	if (strlen(inputFilename) != 0 && strlen(outputFilename) == 0) {

		char asmExtension[NUM_CHAR] = ".asm";
		char srecExtension[NUM_CHAR] = ".srec";
		char outputFile[NUM_CHAR] = "";

		inputFilep = fopen(inputFilename, "rb");

		if (inputFilep == NULL) 
		{
			printf("Failed to open the input file!\n");
			return;
		}

		strcpy(outputFile, inputFilename);

		if (srecSwitch == true) 
		{
			strcat(outputFile, srecExtension);
			outputFilep = fopen(outputFile, "wb");
			if (outputFilep == NULL) 
			{
				printf("Failed to open the output file!\n");
				return;
			}

			srecMode(inputFilep, outputFilep);
		}

		else 
		{
			strcat(outputFile, asmExtension);
			outputFilep = fopen(outputFile, "wb");
			if (outputFilep == NULL) 
			{
				printf("Failed to open the output file!\n");
				return;
			}

			asemMode(inputFilep, outputFilep);
		}
	}

	// if both input and output filenames are specified
	if (strlen(inputFilename) != 0 && strlen(outputFilename) != 0)
	{
		inputFilep = fopen(inputFilename, "rb");
		if (inputFilep == NULL) 
		{
			printf("Failed to open the input file!\n");
			return;
		}

		outputFilep = fopen(outputFilename, "wb");
		if (outputFilep == NULL) 
		{
			printf("Failed to open the output file!\n");
			return;
		}

		if (srecSwitch == true) 
		{
			srecMode(inputFilep, outputFilep);
		}

		else 
		{
			asemMode(inputFilep, outputFilep);
		}
	}



	if (fclose(inputFilep) != 0) 
	{
		printf("Failed to close the input file!\n");
		return;
	}

	if (fclose(outputFilep) != 0) 
	{
		printf("Failed to close the output file!\n");
		return;
	}
}
